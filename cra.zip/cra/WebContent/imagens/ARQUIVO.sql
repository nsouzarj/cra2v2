﻿SET CLIENT_ENCODING TO 'latin1';
COPY comarca FROM 'c:/plan.csv' delimiters ';'