package br.adv.cra.utilitarios;

public class TesteJson {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	TrazProc t = new TrazProc();
	System.out.print(t.traz());	
     
	
	} 

}
